import random
from dino_runner.components.obstacles.obstacle import Obstacle
from dino_runner.utils.constants import BIRD, SCREEN_HEIGHT, SCREEN_WIDTH

class Bird(Obstacle):
    def __init__(self, images):
        self.images = images
        self.image = self.images[0]
        self.rect = self.image.get_rect()
        self.rect.x = SCREEN_WIDTH
        self.rect.y = random.randint(SCREEN_HEIGHT * 0.1, SCREEN_HEIGHT * 0.6)
        self.index = 0
        self.counter = 0
        
    def update(self, speed):
        self.counter += 1
        if self.counter > 10:
            self.counter = 0
            self.index += 1
            if self.index >= len(self.images):
                self.index = 0
            self.image = self.images[self.index]

        self.rect.x -= speed

    def draw(self, screen):
        if self.index >= len(self.images):
            self.index = 0
        self.image = self.images[self.index]
        screen.blit(self.image, self.rect)