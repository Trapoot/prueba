import pygame
from dino_runner.components.obstacles.bird import Bird
from dino_runner.components.obstacles.small_cactus import SmallCactus
from dino_runner.components.obstacles.large_cactus import LargeCactus
import random
from dino_runner.utils.constants import SHIELD_TYPE, SMALL_CACTUS, LARGE_CACTUS, BIRD

class ObstacleManager():

    def __init__(self):
        self.obstacles = []


    def update(self, game):
        if len(self.obstacles) == 0:
            # elegir aleatoriamente uno de los tres tipos de obstáculos posibles: "SmallCactus", "LargeCactus" o "Bird".
            obstacle_type = random.choice([SmallCactus, LargeCactus, Bird])
            if obstacle_type == Bird:
                obstacle_image = BIRD
            else:
                #Si el obstáculo elegido es un cactus, se elige aleatoriamente entre ("SMALL_CACTUS" o "LARGE_CACTUS").
                obstacle_image = random.choice(SMALL_CACTUS if obstacle_type == SmallCactus else LARGE_CACTUS)
            self.obstacles.append(obstacle_type(obstacle_image))
            #crea un nuevo obstáculo y con la imagen seleccionada, y lo añade a la lista de obstáculos del juego

        for obstacle in self.obstacles:
            obstacle.update(game.game_speed)

            if obstacle.rect.x < -obstacle.rect.width:
                self.obstacles.pop()

            if game.player.type == SHIELD_TYPE:
                for obstacle in game.obstacle_manager.obstacles:
                    if game.player.rect.colliderect(obstacle.rect):
                        game.obstacle_manager.obstacles.remove(obstacle)
                        break
            elif game.player.rect.colliderect(obstacle.rect):
                if game.lives > 1:
                    game.lives -= 1
                    game.draw()
                    game.obstacle_manager.obstacles.remove(obstacle)
                    continue
                else:
                    game.playing = False

    def draw(self, screen):
        for obstacle in self.obstacles:
            obstacle.draw(screen)

    def remove_obstacle(self):
        self.obstacles = []