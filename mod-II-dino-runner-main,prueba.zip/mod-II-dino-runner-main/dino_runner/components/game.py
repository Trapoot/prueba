import pygame
from dino_runner.components.cloud import Cloud
from dino_runner.components.obstacle_manager import ObstacleManager
from dino_runner.components.power_up_manager import Powerupmanager
from dino_runner.utils.constants import BG, DEFAULT_TYPE, GAME_OVER, ICON, INITIAL_GAME_SPEED, RESET, SCREEN_HEIGHT, SCREEN_WIDTH, TITLE, FPS
from dino_runner.components.dinosaur import Dinosaur
from dino_runner.utils.text_utils import deaths, get_center_message, get_score_element, life, show_best_score

class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption(TITLE)
        pygame.display.set_icon(ICON)
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()
        self.playing = False
        self.game_speed = INITIAL_GAME_SPEED
        self.x_pos_bg = 0
        self.y_pos_bg = 380
        self.player = Dinosaur()
        self.obstacle_manager = ObstacleManager()
        self.power_up_manager = Powerupmanager()
        self.cloud_group = pygame.sprite.Group()
        self.points = 0
        self.deaht = 1
        self.best_score = 0
        self.lives = 1

    def increase_life(self):
        self.lives += 1 

    def draw_lives(self):
        score, rect = life(self.lives)
        self.screen.blit(score, rect)

    def show_score(self):
        self.points += 1
        if self.points > self.best_score:
            self.best_score = self.points
        if self.points % 50 == 0 and self.points < 200:
            self.game_speed += 1
        score, rect = get_score_element(self.points)
        self.screen.blit(score, rect)
        

    def show_menu(self):
        half_screen_height = SCREEN_HEIGHT // 2
        half_screen_width = SCREEN_WIDTH // 2
        self.screen.fill((255, 255, 255))
        self.screen.blit(GAME_OVER, (half_screen_width - 200, half_screen_height - 220))
        self.screen.blit(ICON, (half_screen_width - 50, half_screen_height - 140))
        self.screen.blit(RESET, (half_screen_width - 50, half_screen_height + 180))
        text, rect = get_center_message("Press any key to star")
        self.screen.blit(text, rect)

        death_text, death_rect = deaths(self.deaht)
        self.screen.blit(death_text, death_rect)

        score, score_rect = get_score_element(self.points)
        self.screen.blit(score, (SCREEN_WIDTH - score_rect.width - 470, 410))

        best_score_text, best_score_rect = show_best_score(self.best_score)
        self.screen.blit(best_score_text, best_score_rect)
        pygame.display.update()

        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                self.run()
                self.deaht += 1
                
    def run(self):
        self.reset_game()
        cloud = Cloud()
        self.cloud_group.add(cloud)
        pygame.mixer.music.load('C:\\Users\\Usuario\\Documents\\Jala University\\rocket.mp3')
        pygame.mixer.music.set_volume(0.05)
        pygame.mixer.music.play(-1)
        self.playing = True
        while self.playing:
            self.events()
            self.update()
            self.draw()
        pygame.time.delay(1000)
        pygame.mixer.music.stop()

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

    def update(self):
        self.user_input = pygame.key.get_pressed()
        self.player.update(self.user_input)
        self.obstacle_manager.update(self)
        self.power_up_manager.update(self)

    def draw(self):
        self.clock.tick(FPS)
        if self.points < 200:
            self.screen.fill((255, 255, 255)) # white background
        elif self.points >= 600:
            self.screen.fill((255, 255, 255)) # white background
        else:
            self.screen.fill((200, 200, 200)) # gray background
        self.draw_background()
        self.player.draw(self.screen)
        self.obstacle_manager.draw(self.screen)
        self.cloud_group.draw(self.screen)
        self.cloud_group.update()
        self.show_score()
        self.power_up_manager.draw(self.screen)
        self.draw_lives()
        pygame.display.update()
        pygame.display.flip()

    def draw_background(self):
        image_width = BG.get_width()
        self.screen.blit(BG, (self.x_pos_bg, self.y_pos_bg))
        self.screen.blit(BG, (image_width + self.x_pos_bg, self.y_pos_bg))
        if self.x_pos_bg <= -image_width:
            self.screen.blit(BG, (image_width + self.x_pos_bg, self.y_pos_bg))
            self.x_pos_bg = 0
        self.x_pos_bg -= self.game_speed


    def reset_game(self):
        self.obstacle_manager.remove_obstacle()
        self.points = 0
        self.game_speed = INITIAL_GAME_SPEED
        self.player.reset()   
        self.lives = 1