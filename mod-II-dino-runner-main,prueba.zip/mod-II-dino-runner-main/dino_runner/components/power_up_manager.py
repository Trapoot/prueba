import random
from dino_runner.components.power_ups.hammer import Hammer
from dino_runner.components.power_ups.shield import Shield
from dino_runner.components.power_ups.life import Life
from dino_runner.utils.constants import DEFAULT_TYPE, HAMMER, HAMMER_TYPE, HEART, LIFE_TYPE, SHIELD, SHIELD_TYPE 

class Powerupmanager():
    POWER_UP_PROBALITY = 20
    LIFE_PROBABILITY = 20
    HAMMER_PROBABILITY = 50

    def __init__(self):
        self.power_ups = []

    def generate_power_up(self):
        random_number = random.randint(0, 1000)
        if random_number < self.POWER_UP_PROBALITY:
            self.power_ups.append(Shield(SHIELD))
        elif random_number < self.POWER_UP_PROBALITY + self.LIFE_PROBABILITY:
            self.power_ups.append(Life(HEART))
        elif random_number < self.POWER_UP_PROBALITY + self.LIFE_PROBABILITY + self.HAMMER_PROBABILITY:
            self.power_ups.append(Hammer(HAMMER))

    def update(self, game):
        if len(self.power_ups) == 0 and game.player.type == DEFAULT_TYPE:
            self.generate_power_up()

        for power_up in self.power_ups:
            power_up.update(game.game_speed)

            if power_up.rect.x < -power_up.rect.width:
                self.power_ups.pop()

            if game.player.rect.colliderect(power_up.rect):
                if power_up.type == SHIELD_TYPE:
                    game.player.activate_power_up(power_up.type)
                elif power_up.type == LIFE_TYPE:
                    game.increase_life()
                elif power_up.type == HAMMER_TYPE:
                    game.player.activate_power_up(power_up.type)
                self.power_ups.remove(power_up)


    def draw(self, screen):
        for power_up in self.power_ups:
            power_up.draw(screen)

