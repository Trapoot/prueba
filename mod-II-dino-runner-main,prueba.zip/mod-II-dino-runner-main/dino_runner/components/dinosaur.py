import pygame
from pygame.sprite import Sprite

from dino_runner.utils.constants import HAMMER_TYPE, JUMP_SOUND, RUNNING_SHIELD, SHIELD, SHIELD_TYPE, DEFAULT_TYPE, RUNNING, JUMPING, DUCKING, JUMPING_SHIELD, DUCKING_SHIELD, DUCKING_HAMMER, JUMPING_HAMMER, RUNNING_HAMMER

class Dinosaur(Sprite):
    X_POS = 80
    Y_POS = 310
    Y_POS_DUCK = 340
    Y_POS_JUMP = 100
    JUMP_VEL = 8.5
    POWER_UP_TIME = 200
    
    
    def __init__(self):
        self.jump_sound = pygame.mixer.Sound(JUMP_SOUND)
        self.jump_sound.set_volume(0.2)
        self.image = RUNNING[1]
        self.rect = self.image.get_rect()
        self.rect.x = self.X_POS
        self.rect.y = self.Y_POS
        self.step_index = 0
        self.current_pos = self.X_POS
        self.dino_duck = False
        self.dino_jump = False
        self.dino_run = True
        self.jump_vel = self.JUMP_VEL
        self.run_img = {DEFAULT_TYPE: RUNNING, SHIELD_TYPE: RUNNING_SHIELD, HAMMER_TYPE: RUNNING_HAMMER}
        self.jump_img = {DEFAULT_TYPE: JUMPING, SHIELD_TYPE: JUMPING_SHIELD, HAMMER_TYPE: JUMPING_HAMMER}
        self.duck_img = {DEFAULT_TYPE: DUCKING, SHIELD_TYPE: DUCKING_SHIELD, HAMMER_TYPE: DUCKING_HAMMER}
        self.type = DEFAULT_TYPE
        self.power_up_time = 0

    def update(self, user_input):
        #el dinosaurio esta corriendo y no esta saltando, se llama a la funcion run()
        if self.dino_run and not self.dino_jump:
            self.run()
        if self.dino_jump:
            self.jump()

        if (user_input[pygame.K_UP] or user_input[pygame.K_SPACE]) and not self.dino_jump:
            self.dino_duck = False
            self.dino_run = False
            self.dino_jump = True
            self.jump_sound.play()
        elif user_input[pygame.K_DOWN] and not self.dino_jump:
            self.dino_run = False
            self.dino_jump = False
            self.dino_duck = True
            self.duck()
        else:
            self.dino_run = True

        if user_input[pygame.K_LEFT]:
            self.current_pos -= 5
            self.rect.x = self.current_pos
        elif user_input[pygame.K_RIGHT]:
            self.current_pos += 5
            self.rect.x = self.current_pos

        self.step_index += 1
        if self.step_index > 10:
            self.step_index = 0

        self.power_up_time -= 1
        if self.power_up_time <= 0:
            self.type = DEFAULT_TYPE


    def draw(self, screen):
        screen.blit(self.image, self.rect)

    def run(self):
        if self.step_index < 5:
            self.image = self.run_img[self.type][0]
        else:
            self.image = self.run_img[self.type][1]
        self.rect = self.image.get_rect()
        self.rect.y = self.Y_POS
        self.rect.x = self.current_pos

    def jump(self):
        self.image = self.jump_img[self.type]
        if self.dino_jump:
            self.rect.y -= self.jump_vel * 4
            self.jump_vel -= 0.8
        if self.jump_vel < -self.JUMP_VEL:
            self.dino_jump = False
            self.jump_vel = self.JUMP_VEL
            self.rect.x = self.current_pos
            

    def duck(self):
        if self.step_index < 5:
            self.image = self.duck_img[self.type][0]
        else:
            self.image = self.duck_img[self.type][1]
        self.rect = self.image.get_rect()
        self.rect.y = self.Y_POS_DUCK
        self.rect.x = self.current_pos

    def activate_power_up(self, power_up_type):
        if power_up_type == SHIELD_TYPE:
            self.type = SHIELD_TYPE
            self.power_up_time = self.POWER_UP_TIME
        elif power_up_type == HAMMER_TYPE:
            self.type = HAMMER_TYPE
            self.power_up_time = self.POWER_UP_TIME
            self.rect.y = self.Y_POS + 30
            self.rect.y = self.current_pos

    def reset(self):
        self.image = RUNNING[1]
        self.rect = self.image.get_rect()
        self.rect.x = self.X_POS
        self.rect.y = self.Y_POS
        self.step_index = 0
        self.current_pos = self.X_POS
        self.dino_duck = False
        self.dino_jump = False
        self.dino_run = True
        self.jump_vel = self.JUMP_VEL
