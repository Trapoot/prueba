import pygame

from dino_runner.utils.constants import SCREEN_HEIGHT, SCREEN_WIDTH

FONT_STYLE = 'freesansbold.ttf'
BLACK_COLOR = (0, 0, 0)

def get_score_element(score):
    font = pygame.font.Font(FONT_STYLE, 30)
    text = font.render(f"Points: {score}", True, BLACK_COLOR)
    rect = text.get_rect()
    rect.center = (1000, 30)
    return text, rect

def life(lives):
    font = pygame.font.Font(FONT_STYLE, 25)
    text = font.render(f"Lives: {lives}", True, BLACK_COLOR)
    rect = text.get_rect()
    rect.center = (90, 30)
    return text, rect

def get_center_message(message):
    font = pygame.font.Font(FONT_STYLE, 30)
    text = font.render(message, True, BLACK_COLOR)
    rect = text.get_rect()
    rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 )
    return text, rect

def deaths(death):
    font = pygame.font.Font(FONT_STYLE, 30)
    text = font.render(f"Deaths: {death}", True, BLACK_COLOR)
    rect = text.get_rect()
    rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 40)
    return text, rect

def show_best_score(best_score):
    font = pygame.font.Font(FONT_STYLE, 30)
    text = font.render(f"Best score: {best_score}", True, BLACK_COLOR)
    rect = text.get_rect()
    rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 80)
    return text, rect